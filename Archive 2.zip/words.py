import re

class WordMapper():
    def __init__(self, objects, all_object_names):
        self.tags = set()
        self.function_keywords = list(WordMapper.fun_map.keys()) 
        self.non_tags = ['AND', 'OR', 'BETWEEN', 'IN', 'null', 'not_in', 'NULL', 'contains', 'CONTAINS', 'in', 'and']
        self.non_tags += all_object_names + self.function_keywords + [k.upper() for k in self.function_keywords]
        self.all_object_names = all_object_names
        self.manuals = set()
        self.executors = set()
        self.possible_tags = set()
        self.loops = set()
        self.get_possible_tags(objects)

    def get_possible_tags(self, objects):
        for obj in objects:
            words = re.findall(r'\w+', obj.attributes.get('result').value)
            for x in words:
                if x not in self.non_tags and all(not c.isnumeric() for c in x) and not x.isupper() and len(x) > 2:
                    self.tags.add(x)
                elif 'comment' in x or '1st' in x or 'late' in x:
                    self.tags.add(x)
                else:
                    has_numeric = len([c for c in x if c.isnumeric()])
                    has_alpha = len([c for c in x if c.isalpha()])
                    if has_numeric and has_alpha and not x.isupper() and '_' not in x and 'V5' not in x:
                        self.tags.add(x)

    def remove_island_multi_whites(self, res):
        res = res.strip() 
        new_res = ''
        next_join_i = 0
        for match in re.finditer('([^\s]|[\n])(\s{2}|\s{3}|\s{4})[^\s]', res):
            start_space_i = match.start() + 1
            end_space_i = match.end() - 1
            not_if_or_and = res[end_space_i:end_space_i+3] not in ('IF ', 'OR ', 'AND')
            not_return = 'RETURN ' != res[end_space_i:end_space_i+7]
            not_else_then_set = res[end_space_i:end_space_i+4] not in ('ELSE', 'THEN', '(SET', 'SET ')
            not_endif = 'ENDIF' != res[end_space_i:end_space_i+5]
            if not_if_or_and and not_return and not_else_then_set and not_endif:
                new_res += res[next_join_i:start_space_i]    
                if res[match.start()] != '\n':
                    new_res += ' '
            else:
                new_res += res[next_join_i:end_space_i]
            next_join_i = end_space_i
        new_res += res[next_join_i:]
        return new_res

    def tag_transform(self, obj, result):
        tags_in_result = list()
        seg = f"{obj.attributes.get('class').value[:2]}."

        for tag in self.tags:
            if tag in result:
                i = 0
                while i < len(result):
                    if result[i:i+len(tag)] == tag:
                        before_tag = result[i-1] if i > 0 else ' '
                        after_tag = result[i+len(tag)] if i + len(tag) < len(result) else ' '
                        good_before = not before_tag.isalpha() and not before_tag.isnumeric() and before_tag not in ('.', '_')
                        good_after = not after_tag.isalpha() and not after_tag.isnumeric() and after_tag != '_'
                        if good_before and good_after:
                            result = f'{result[:i]}{seg}{result[i:]}'
                            tags_in_result.append(f'{seg}{tag}')
                    i += 1
        if f'{seg}.{seg}.' in result:
            import pdb;pdb.set_trace()
        return {'result': result, 'tags_in_result': list(set(tags_in_result))}

    def sub_comp_transform(self, result, generator, obj):
        sub_comps_to_add = list()
        new_res = result
        for i, name in enumerate(self.all_object_names):
            name_count = result.count(name)
            non_match_count = 0
            for j in range(name_count):
                start_i = [m.start() for m in re.finditer(name, new_res)][non_match_count]
                after_name = new_res[start_i + len(name)] if (start_i + len(name) < len(new_res)) else ' '
                if after_name != '_' and not after_name.isnumeric() and not after_name.isalpha():
                    if ';' in new_res[start_i+len(name):start_i+len(name)+3]:
                        self.executors.add(obj)
                    formatted_name = generator.namer.style_name(name, generator.namer.one_to_one_transforms[name])
                    new_res = new_res[:start_i] + new_res[start_i:start_i+len(name)].replace(name, formatted_name) + new_res[start_i+len(name):]
                    sub_comps_to_add.append(formatted_name)
                else:
                    non_match_count += 1
        for name in self.all_object_names:
            if name in new_res:
                import pdb;pdb.set_trace()
        return {'result': new_res, 'sub_comps': list(set(sub_comps_to_add))}

    def iif_nest_check(self, args, name):
        all_args = ' '.join([arg['text'] for arg in args]).lower()
        if 'iff(' in all_args or 'iff (' in all_args:
            self.manuals.add(name)

    def get_args(self, links, dim, result, char_dims):
        args = list()
        last_arg_end_index = 0
        quote_status, previous_quote = 0, ''
        for i, link in enumerate(links):
            if link['char'] == ',' and link['dim'] == dim and not quote_status:
                arg_slice = slice(links[last_arg_end_index]['abs_index'], link['abs_index']) 
                args.append({'text': result[arg_slice], 'char_dims': char_dims[arg_slice]})
                last_arg_end_index = i+1
            elif link['char'] in ('"',"'") and (previous_quote == link['char'] or not quote_status):
                previous_quote = link['char']
                quote_status = round( abs( quote_status - .84 ) )

        last_arg_slice = slice(links[last_arg_end_index]['abs_index'], links[-1]['abs_index']+1)
        args.append({'text': result[last_arg_slice], 'char_dims': char_dims[last_arg_slice]})

        return args


    def get_transformation_map(self, arg_map, hard_text_dim, fun):
        mapped_transformation = {'result': '', 'char_dims': list()}
        for data in arg_map:
            mapped_transformation['result'] += data['before_arg_text'] + data['arg_text'] + data['after_arg_text']
            before_arg_dims = [hard_text_dim for i in range(len(data['before_arg_text']))]
            after_arg_dims = [hard_text_dim for i in range(len(data['after_arg_text']))]
            try:
                mapped_transformation['char_dims'] += before_arg_dims + data['arg_dims'] + after_arg_dims
            except Exception:
                import pdb;pdb.set_trace()
        return mapped_transformation

    def get_placement_map(self, arg_text, before_arg_text, after_arg_text, arg_dims):
        return  {'arg_text': arg_text, 'before_arg_text': before_arg_text, 'after_arg_text': after_arg_text, 'arg_dims': arg_dims}

    def iif_special_transform(self, texts_dict, hard_dim):
        char_dims = list()
        text = ''
        for (hard_text, arg) in texts_dict.items():
            text += hard_text + arg['text']
            char_dims += [(hard_dim+1) for i in range(len(hard_text))] + [dim for dim in arg['dims']]
        return {'char_dims': char_dims + [hard_dim+1], 'text': text + ')'}

    def get_iif_isnull_place(self, non_null_return, non_null_dims, null_return, null_return_dim, hard_dim):
        placement_params = self.iif_special_transform({
            'IIF(': {
                'text': non_null_return, 
                'dims': non_null_dims
            }, 
            ' <> NULL, ': {
                'text': non_null_return, 
                'dims': non_null_dims
            },
            ', ': {
                'text': null_return, 
                'dims': null_return_dim
            }
        }, hard_dim)
        return self.get_placement_map(placement_params['text'], ', ', '', placement_params['char_dims'])

    def arocc(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[1]['text'], 'COUNT of VALUE ', '', args[1]['char_dims'])
        second_place = self.get_placement_map(args[2]['text'], ' in COLUMN ', '', args[2]['char_dims'])
        third_place = self.get_placement_map(args[0]['text'], ' of ARRAY ', '', args[0]['char_dims'])
        placements = [first_place, second_place, third_place]
        if len(args) == 5:
            fourth_place = self.get_placement_map(args[3]['text'], ' from POSITIONS ', '', args[3]['char_dims'])
            fifth_place = self.get_placement_map(args[4]['text'], ' to ', '', args[4]['char_dims'])
            placements += [fourth_place, fifth_place]
        return placements

    def rtrim(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', ' WITHOUT trailing whitespace', args[0]['char_dims'])
        return [first_place]

    def val_max(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'MAX(', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ', ', ')', args[1]['char_dims'])
        return [first_place, second_place]

    def strlen(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'LENGTH(', ')', args[0]['char_dims'])
        return [first_place]

    def left(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ' FIRST ', ' CHARACTERS', args[1]['char_dims'])
        return [first_place, second_place]

    def right(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[1]['text'], 'LAST ', '', args[1]['char_dims'])
        second_place = self.get_placement_map(args[0]['text'], ' CHARACTERS of ', '', args[0]['char_dims'])
        return [first_place, second_place]

    def substr(self, args, obj):
        self.iif_nest_check(args, obj)
        if args[1]['text'].strip() in ('1', "'1'", '"1"'):
            first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
            second_place = self.get_placement_map(args[2]['text'], ' FIRST ', ' CHARACTERS', args[2]['char_dims'])
            placements = [first_place, second_place]
        elif args[2]['text'].replace(' ', '') in ('1', "'1'", '"1"'):
            first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
            second_place = self.get_placement_map(args[1]['text'], ' CHARACTER at POSITION ', '', args[1]['char_dims'])
            placements = [first_place, second_place]
        else: 
            first_place = self.get_placement_map(args[0]['text'], 'SUBSTRING ', '', args[0]['char_dims'])
            second_place = self.get_placement_map(args[2]['text'], ' with LENGTH ', '', args[2]['char_dims'])
            third_place = self.get_placement_map(args[1]['text'], ' STARTING at POSITION ', '', args[1]['char_dims'])
            placements = [first_place, second_place, third_place]
        return placements

    def datestr(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', ' as MM/DD/YY DATESTRING', args[0]['char_dims'])
        return [first_place]

    # Note that an att as arg which may or may not return 0 must be handled specially
    def substitute(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ' with ALL ', '', args[1]['char_dims'])
        third_place = self.get_placement_map(args[2]['text'], ' REPLACED by ', '', args[2]['char_dims'])
        placements = [first_place, second_place, third_place]
        if args[3]['text'].strip() != '0':
            second_place = self.get_placement_map(args[3]['text'], ' with occurence ', '', args[3]['char_dims'])
            third_place = self.get_placement_map(args[1]['text'], ' of ', '', args[1]['char_dims'])
            fourth_place = self.get_placement_map(args[2]['text'], ' REPLACED by ', '', args[2]['char_dims'])
            placements[1:] = [second_place, third_place, fourth_place]
        return placements

    def isnull(self, args, obj):
        if args[0]['text'].strip()[:3].lower() != 'iif':
            first_place = self.get_placement_map(args[0]['text'], 'IIF(', '', args[0]['char_dims'])
            second_place = self.get_placement_map(args[0]['text'], ' <> NULL, ', '', args[0]['char_dims'])
            third_place = self.get_placement_map(args[1]['text'], ', ', ')', args[1]['char_dims']) 
            return [first_place, second_place, third_place]
        else:
            return self.isnull_first_arg_iif(args, obj)

    def get_non_whitespace_start(self, start, iif_text, increment):
        while increment:
            if type(start+increment) != int:
                import pdb;pdb.set_trace()
            if iif_text[start+increment] != ' ':
                return start + increment
            increment *= (abs(increment)+1) // abs(increment)

    def isnull_first_arg_iif(self, args, obj):
        iif = args[0]['text']
        all_dims = args[0]['char_dims']
        meta_iif = {
            'iif_dim': all_dims[iif.lower().index('iif')], 
            'null_return': args[1]['text'], 
            'null_return_dim': [(i+1) for i in args[1]['char_dims']]
        }
        for i, c in enumerate(iif):
            if all_dims[i] == meta_iif['iif_dim']:
                if c == ',':
                    if 'first_comma_index' not in meta_iif:
                        meta_iif['first_comma_index'] = i
                    else:
                        meta_iif['second_comma_index'] = i
                elif c == '(':
                    meta_iif['open_paren_index'] = i
                elif c == ')':
                    meta_iif['close_paren_index'] = i

                    first_arg_slice = slice(
                        self.get_non_whitespace_start(meta_iif['open_paren_index'], iif, 1), 
                        self.get_non_whitespace_start(meta_iif['first_comma_index'], iif, -1)+1
                    )
                    meta_iif['first_arg'] = iif[first_arg_slice]
                    meta_iif['first_arg_dims'] = [(dim-1) for dim in all_dims[first_arg_slice]]
                    first_place = self.get_placement_map(meta_iif['first_arg'], 'IIF(', '', meta_iif['first_arg_dims'])

                    second_arg_slice = slice(
                        self.get_non_whitespace_start(meta_iif['first_comma_index'], iif, 1), 
                        self.get_non_whitespace_start(meta_iif.get('second_comma_index', meta_iif['close_paren_index']), iif, -1) + 1
                    )
                    meta_iif['second_arg'], meta_iif['second_arg_dims'] = iif[second_arg_slice], all_dims[second_arg_slice]
                    params = [meta_iif['second_arg'], meta_iif['second_arg_dims'], meta_iif['null_return'], meta_iif['null_return_dim'], meta_iif['iif_dim']-1]
                    second_place = self.get_iif_isnull_place(*params) 
                    
                    placements = [first_place, second_place]
                    last_place = self.get_placement_map('', '', ')', [])
                    if 'second_comma_index' in meta_iif:
                        third_arg_slice = slice(
                            self.get_non_whitespace_start(meta_iif['second_comma_index'], iif, 1),
                            self.get_non_whitespace_start(meta_iif['close_paren_index'], iif, -1) + 1
                        )
                        meta_iif['third_arg'], meta_iif['third_arg_dims'] = iif[third_arg_slice], all_dims[third_arg_slice]
                        params = [meta_iif['third_arg'], meta_iif['third_arg_dims'], meta_iif['null_return'], meta_iif['null_return_dim'], meta_iif['iif_dim']-1]
                        third_place = self.get_iif_isnull_place(*params)
                        placements.append(third_place)
                    placements.append(last_place)

                    return placements
            
    def strinstr(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'FIRST POSITION of ', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ' in ', ' IF EXISTS *or 0 if not present*', args[1]['char_dims'])
        return [first_place, second_place]

    def assign(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'SET ', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ' to ', '\n', args[1]['char_dims'])
        return [first_place, second_place]

    def round_num(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', ' ROUNDED to INTEGER', args[0]['char_dims'])
        return [first_place]

    def countchar(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[1]['text'], 'COUNT of ', '', args[1]['char_dims'])
        second_place = self.get_placement_map(args[0]['text'], ' in ', '', args[0]['char_dims'])
        return [first_place, second_place]

    def repeat(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ' REPEATED ', ' TIMES', args[1]['char_dims'])
        return [first_place, second_place]

    def text_reverse(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'REVERSED ', '', args[0]['char_dims'])
        return [first_place]

    def replace(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[3]['text'], ' with ', '', args[3]['char_dims'])
        third_place = self.get_placement_map(args[1]['text'], ' INSERTED at position ', '', args[1]['char_dims'])
        placements = [first_place, second_place, third_place]
        if args[2]['text'].strip() != '0':
            third_place = self.get_placement_map(args[2]['text'], ' REPLACING ', '', args[2]['char_dims'])
            fourth_place = self.get_placement_map(args[1]['text'], ' CHARACTER(s) at POSITION ', '', args[1]['char_dims']) 
            placements[2:] = [third_place, fourth_place]
        return placements

    def trim(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', ' WITH boundary whitespace + multiple embedded whitespace REMOVED', args[0]['char_dims']) 
        return [first_place]
    
    def stringi(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', '', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], ' CONVERTED to NUMBERSTRING with >= ', ' digits (prepend 0\'s if required)', args[1]['char_dims'])
        return [first_place, second_place]

    def abso(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'ABS(', ')', args[0]['char_dims'])
        return [first_place]

    def findchars(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[3]['text'], 'COUNT of ', '', args[3]['char_dims'])
        second_place = self.get_placement_map(args[0]['text'], ' in ', '', args[0]['char_dims'])
        placements = [first_place, second_place]
        arg2_wo_length = args[2]['text'].replace(' ','').replace('LENGTH', '').replace('(', '').replace(')', '')
        not_full_search = not args[0]['text'].strip() == arg2_wo_length
        if args[1]['text'].replace(' ', '') in ("'1'", '"1"', '1') and not_full_search:
            placements.append(self.get_placement_map(args[2]['text'], ' FIRST ', ' CHARACTERS ', args[2]['char_dims']))
        else:
            third_place = self.get_placement_map(args[1]['text'], ' STARTING at position ', '', args[1]['char_dims'])
            fourth_place = self.get_placement_map(args[2]['text'], ' with SEARCH RANGE of ', ' characters', args[2]['char_dims'])
            placements += [third_place, fourth_place]

        return placements

    def num(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', ' CONVERTED to NUMBER', args[0]['char_dims'])
        return [first_place]

    # FOUND BUG! REDO ALL PSEUDOCODE CALCULATIONS WHICH CALL UPON THE MIN FUNCTION
    def val_min(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'MIN(', ', ', args[0]['char_dims'])
        second_place = self.get_placement_map(args[1]['text'], '', ')', args[1]['char_dims'])
        return [first_place, second_place]

    def fix(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], '', ' CONVERTED to 0 decimal FLOAT', args[0]['char_dims'])
        return [first_place]

    def arcount(self, args, obj):
        self.iif_nest_check(args, obj)
        first_place = self.get_placement_map(args[0]['text'], 'LENGTH of ARRAY ', '', args[0]['char_dims'])
        return [first_place]
    
    def arsort(self, args, obj):
        self.iif_nest_check(args, obj)
        sort_order = 'DESCENDING' if args[-1]['text'] == '1' else 'ASCENDING'
        sort_order_dims = [args[-1]['char_dims'][0] for c in sort_order]
        first_place = self.get_placement_map(args[0]['text'], 'ARRAY ', '', args[0]['char_dims'])
        second_place = self.get_placement_map(sort_order, ' SORTED ', '', sort_order_dims)
        third_place = self.get_placement_map(args[1]['text'], ' on COLUMN ', '', args[1]['char_dims'])
        return [first_place, second_place, third_place]

    fun_map = {'rtrim': rtrim, 'max': val_max, 'strlen': strlen, 'left': left, 'substr': substr, 'datestr': datestr, 'substitute': substitute, 'findchars': findchars,
    'isnull': isnull, 'strinstr': strinstr, 'assign': assign, 'int': round_num, 'round': round_num, 'countchar': countchar, 'rept': repeat, 'textreverse': text_reverse,
    'replace': replace, 'trim': trim, 'stringi': stringi, 'abs': abso, 'num': num, 'min': val_min, 'fix': fix, 'arocc': arocc, 'arcount': arcount, 'sort': arsort, 'right': right}

