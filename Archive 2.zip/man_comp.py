import xlrd
from openpyxl import Workbook
from openpyxl.styles import Alignment

wbr1 = xlrd.open_workbook('tC_revise_to_compare.xlsx')
wbr2 = xlrd.open_workbook('t41_revise_to_compare.xlsx')
wbr3 = xlrd.open_workbook('t4_revise.xlsx')
wsr1 = wbr1.sheet_by_index(0)
wsr2 = wbr2.sheet_by_index(0)
wsr3 = wbr3.sheet_by_index(0)

transfer_wb = Workbook()
transfer_ws = transfer_wb.active

non_transfer_wb = Workbook()
non_transfer_ws = non_transfer_wb.active

good_revisions = dict()
for i in range(wsr3.nrows):
    name = wsr3.cell_value(i, 0)
    calc = wsr3.cell_value(i, 1)
    good_revisions[name] = calc


for i in range(wsr1.nrows):
    name1 = wsr1.cell_value(i, 0)
    calc1 = wsr1.cell_value(i, 1)
    matched = False
    for j in range(wsr2.nrows):
        calc2 = wsr2.cell_value(j, 1)
        name2 = wsr2.cell_value(j, 0)
        if calc1.strip() == calc2.strip() and name1 == name2.replace('_T41_', '_TUC_'):
            transfer_ws.append([name1, good_revisions[name2.replace('_T41_', '_T40_')]])
            matched = True
    if not matched:
        non_transfer_ws.append([name1, calc1])

for row in transfer_ws.iter_rows():
    for cell in row:
        cell.alignment = Alignment(wrap_text=True)

for row in non_transfer_ws.iter_rows():
    for cell in row:
        cell.alignment = Alignment(wrap_text=True)

transfer_wb.save('tC_revised_transfers.xlsx')
non_transfer_wb.save('tC_revise.xlsx')
