import xlrd
from openpyxl import Workbook
from openpyxl.styles import Alignment

wbr = xlrd.open_workbook('tC_man.xlsx')
wsr = wbr.sheet_by_index(0)

wbw_revise = Workbook()
wbw_revised = Workbook()
for i in range(wsr.nrows):
    revised = False
    name = wsr.cell_value(i, 0)
    calc = wsr.cell_value(i, 1)
    if 'GROUPED_INQ_VAL_' in name and len(name) == 40:
        revised = True
        calc = ''
        abbr = name[-9:-6].lower()
        num = name[-2:]
        holdcat = f'holdcat_{abbr}_nc0{num}'
        holddate = f'holddate_{abbr}_nc0{num}'
        calc += f"IF [CAT_PRD2] IN ('AUT', 'MRE')\n    "
        calc += f"IF {holdcat} DOESN'T EXIST INITIIALIZE {holdcat} to NULL\n    "
        calc += f"IF {holddate} DOESN'T EXIST INITIIALIZE {holddate} to NULL\n    "
        calc += f"IF {holdcat} <> NULL\n        "
        calc += f"SET {holdcat} to [CAT_PRD2]\n        "
        calc += f"SET {holddate} to IQ.daterep\n        "
        calc += f"RETURN 1\n    ELSE\n        "
        calc += f"IF ABS({holddate} - IQ.daterep) >= 30\n            "
        calc += f"SET {holddate} to IQ.daterep\n            RETURN 1\n        "
        calc += f"ELSE\n            RETURN 0\n        ENDIF\n    ENDIF\nELSE\n    "
        calc += f"RETURN 1\nENDIF"
    elif 'US008' == name[-5:]:
        revised = True
        abbr1 = name[-11]
        abbr2 = name[-9:-6]
        f_name = f'<FL_{abbr1}_{abbr2}_US007>'
        calc = f"IF {f_name} in (0, NULL)\n    {calc[calc.index('RETURN NULL'):]}"
    elif len(name) == 27 and '_FLAG_0' == name[-9:-2] and len(calc.split('\n')) == 12:
        revised = True
        calc_lines = calc.split('\n')
        flag_name = calc_lines[2].strip()[4:15]
        condition = calc_lines[3].strip()
        calc = f"IF {flag_name} DOESN'T EXIST\n    INITIALIZE {flag_name}\nELSE\n    "
        calc += f"IF {flag_name} <> 1\n{' '*8}{condition}\n{' '*12}SET {flag_name} to 1\n"
        calc += f"{' '*8}ELSE\n{' '*12}SET {flag_name} to 0\n{' '*8}ENDIF\n    ENDIF\nENDIF\n"
        calc += f"\nRETURN {flag_name}"
    elif '_V6_MTHS_SINCE' in name:
        revised = True
        num = name[-1]  
        lines = calc.split('\n')
        lines[3] = f'    IF {num} NOT IN [PROFILE]'
        if 'MOST_RECENT' not in name:
            num_found_return = f'RETURN LAST POSITION of {num} in [PROFILE]'
        else:
            num_found_return = f'RETURN FIRST POSITION of {num} in [PROFILE]'
        lines[-3] = f"{' '*8}{num_found_return}"
        calc = '\n'.join(lines)    
    elif name[9:17] in ('_V6_120P', '_V6_90P_', '_V6_60P_', '_V6_30P_'):
        revised = True
        calc = 'IF [PROFILE] = NULL\n    RETURN 0\nELSE\n    SET (pos7, pos8, pos9)  to (0, 0, 0)\n'
        calc += f"    IF <DEROG_7_POS> <> -1\n{' '*8}SET pos7 to LENGTH([PROFILE]) - <DEROG_7_POS>\n    ENDIF\n"
        calc += f"    IF <DEROG_8_POS> <> -1\n{' '*8}SET pos8 to LENGTH([PROFILE]) - <DEROG_8_POS>\n    ENDIF\n"
        calc += f"    IF <DEROG_9_POS> <> -1\n{' '*8}SET pos9 to LENGTH([PROFILE]) - <DEROG_9_POS>\n    ENDIF\n"
        if 'EVER' == name[-4:]:
            chars_to_search = 'LENGTH([PROFILE])'
            search_range = ''
            search_term = name.split('_')[-2][:-1]
        else:
            chars_to_search = int(name.split('_')[-1]) + 1
            search_range = f' FIRST {chars_to_search} CHARACTERS'
            search_term = name.split('_')[-3][:-1]
        search_term = {'120': "'5-6'", '90': "'4-6'", '60': "'3-6'", '30': "'2-6'"}[search_term]
        calc += f"    SET char_count to COUNT of ({search_term}) in [PROFILE]{search_range}\n    "
        calc += f"IF MAX(pos7, pos8, pos9) BETWEEN (1, {chars_to_search})\n{' '*8}RETURN char_count + 1\n"
        calc += f"    ELSE\n{' '*8}RETURN char_count\n    ENDIF\nENDIF"

    calc = calc.replace('~0', '').replace(' ~ 0', '').replace('~ 0', '')

    if revised:
        wbw_revised.active.append([name, calc])
    else:
        wbw_revise.active.append([name, calc])

for row in wbw_revised.active.iter_rows():
    for cell in row:
        cell.alignment = Alignment(wrap_text=True)

for row in wbw_revise.active.iter_rows():
    for cell in row:
        cell.alignment = Alignment(wrap_text=True)


wbw_revise.save('tC_revise_to_compare.xlsx')
wbw_revised.save('tC_revised.xlsx')