from xml.dom import minidom
# from .names import NameSpaceMapper
# from .query import QueryHandler
# from .words import WordMapper
from names import NameSpaceMapper
from query import QueryHandler
from words import WordMapper
import re
from openpyxl import Workbook # For writing to an excel sheet
from openpyxl.styles import Alignment # For styling an excel sheet

class PseudocodeGenerator():
    def __init__(self, xml_raw_loc, bureau):
        self.bureau = bureau
        self.xml = minidom.parse(xml_raw_loc)
        self.query = QueryHandler(self.xml)
        self.namer = NameSpaceMapper(self.xml, self.query, self.bureau)
        self.all_object_names = [obj.attributes.get('name').value for obj in self.query.get_all_objects()]
        self.attribute_generator = self.AttributeGenerator(self)
        self.loop_generator = self.LoopGenerator(self)
        self.filter_generator = self.FilterGenerator(self)
        self.interrogation_generator = self.InterrogationGenerator(self)
    
    def __init__child__(self, child, objects):
        child.objects, child.namer, child.all_object_names = objects, self.namer, self.all_object_names
        child.generator_object_names = [obj.attributes.get('name').value for obj in objects]
        child.wo_sub_comps, child.object_map, child.parent = list(), dict(), self

    def init_object_map(self, child, obj):
        sub_comps, calculation = list(), obj.attributes.get('result').value
        description, object_type = obj.attributes.get('description').value, 'summary attribute' 
        last_update = obj.attributes.get('datelastupdated').value
        full_name = obj.attributes.get('name').value
        name = child.namer.one_to_one_transforms[full_name]

        if full_name[:2] != 'GV':
            object_type = 'component'
            tag_transforms = child.word_mapper.tag_transform(obj, calculation)
            calculation = tag_transforms['result']
            sub_comps += tag_transforms['tags_in_result']

        sub_comp_transforms = child.word_mapper.sub_comp_transform(calculation, self, full_name)
        calculation = sub_comp_transforms['result']
        sub_comps += sub_comp_transforms['sub_comps']

        keys = ['name', 'calculation', 'object_type', 'sub_components', 'description', 'data_note']
        values = [name, calculation, object_type, ' '.join(sub_comps), description, last_update]
        child.object_map[full_name] = {keys[i]:values[i] for i in range(len(keys))} 

        return child.object_map[full_name]


    class InterrogationGenerator():
        def __init__(self, parent):
            objects_to_generate = parent.query.get_lookups()
            parent.__init__child__(self, objects_to_generate)

        def transcribe_interrogations(self, table):
            # Get and bifurcate function name to adhere to pseudocode standard format
            name = table.attributes.get('name').value

            self.object_map[name] = {
                'name': self.namer.style_name(name, self.namer.one_to_one_transforms[name]),
                'description': table.attributes.get('description').value,
                'sub_components': list(), 'interrogations': list()
            }

            # Get segment abbreviation for sub-component naming purposes
            segment_abbr = name[3:5]

            # The default return value which is returned if all specified cases return FALSE
            default_return = table.getElementsByTagName('ELSE')[0].attributes.get('result').value

            if default_return.isupper() and "'" not in default_return and default_return != 'NULL':
                default_return = self.namer.style_name(default_return, self.namer.one_to_one_transforms[default_return])
            elif "'" not in default_return and not default_return.isupper() and not default_return.replace('.','').isnumeric():
                default_return = f'{segment_abbr}.{default_return}'
            self.object_map[name]['sub_components'].append(default_return)
            
            # Loop over the specific cases to parse out its conditional check, return, and any dependencies on sub-components
            for case in table.getElementsByTagName('CASE'):
                return_value = case.attributes.get('result').value
                condition_parameter = case.attributes.get('typevalue').value
                operator = case.attributes.get('operator').value.lower()
                condition_value = case.attributes.get('value').value

                if condition_parameter.isupper():
                    condition_parameter = self.namer.style_name(condition_parameter, self.namer.one_to_one_transforms[condition_parameter])         
                else:
                    condition_parameter = f'{segment_abbr}.{condition_parameter}'
                self.object_map[name]['sub_components'].append(condition_parameter)

                no_quote_in_return = "'" not in return_value
                return_is_numerical = return_value.replace('.','').isnumeric()
                if return_value.isupper() and no_quote_in_return:
                    return_value = self.namer.style_name(return_value, self.namer.one_to_one_transforms[return_value])
                elif no_quote_in_return and not return_value.isupper() and not return_is_numerical:
                    return_value = f'{segment_abbr}.{return_value}'
                self.object_map[name]['sub_components'].append(return_value)

                self.object_map[name]['interrogations'].append([condition_parameter, operator, condition_value, return_value])
            
            self.object_map[name]['sub_components'] = list(set(self.object_map[name]['sub_components']))
            
        def create_pseudocode(self):
            for i, obj in enumerate(self.objects):
                print(i)
                self.transcribe_interrogations(obj)

    class LoopGenerator():
        segment_map = {
            'AKsegment': 'ALIAS', 'CAsegment': 'ADDRESS', 'CSsegment': 'CONSUMER STATEMENT', 'HIsegment': 'HIT LEVEL',
            'DLsegment': 'DELINQUENCY ALERT', 'IQsegment': 'INQUIRY', 'GPsegment': 'GENERAL PURPOSE',
            'IDsegment': 'IDENTIFICATION', 'MIsegment': 'MISCELLANEOUS', 'RWsegment': 'RAW', 'SUsegment': 'SUMMARY',
            'TRsegment': 'TRADELINE', 'THsegment': 'TRADE HISTORY', 'PUsegment': 'PUBLIC RECORD'
        }

        def __init__(self, parent):
            objects_to_generate = parent.query.get_loops()
            parent.__init__child__(self, objects_to_generate)

        def transcribe_loops(self, loop):
            # Node with more specific loop information
            loop_specifics = loop.childNodes[1]
        
            # Set key data points into variables which will be used to construct pseudocode string
            name = loop.attributes.get('name').value
            self.object_map[name] = {
                'name': self.namer.style_name(name, self.namer.one_to_one_transforms[name]),
                'description': loop.attributes.get('description').value,
                'sub_components': list()
            }
            self.object_map[name]['name'] = self.namer.style_name(name, self.namer.one_to_one_transforms[name]) 
            segment = loop_specifics.attributes.get('object').value

            # Build first line of pseudocode string
            init_string = f'SET {self.object_map["name"]} to 0\n\n'

            # Build sort statement which will appear in FOR EACH line
            sort_statement = ''
            # All sorts are executed with respect to some attribute, it is assigned to a variable here below
            sort_attr = loop_specifics.attributes.get('sort').value
            # Parse out proper name format for the sort attribute
            if sort_attr.isupper():
                formatted_name = self.namer.style_name(sort_attr, self.namer.one_to_one_transforms[sort_attr])
                self.object_map[name]['sub_components'].append(formatted_name)
                sort_attr = f'by {formatted_name}'
            elif sort_attr != '':
                self.object_map[name]['sub_components'].append(f'{segment[:2]}.{sort_attr}')
                sort_attr = f'by {segment[:2]}.{sort_attr}'

            # Assign the order of the sort then use to build the sort statement
            order = 'ASCENDING' if loop_specifics.attributes.get('descending') == '1' else 'DESCENDING'
            sort_statement = '' if sort_attr == '' else f'SORTED {order} {sort_attr}'
            # Build the FOR EACH declaration string using proper segment and sort notation
            loop_declaration_string = f'FOR EACH {self.segment_map[segment]} SEGMENT {sort_statement}\n'
            
            # Build IF/ELSE conditions, check for multiple conditions (in which case add THEN)
            filter_condition_string = ''
            # Filter info embedded in xml element in a string delimited by 'AND', so split on 'AND' to create list of filters
            filters = loop_specifics.attributes.get('filter').value.split(' AND ')
            # Only add conditions to IF/ELSE pseudocode statement if there are any filters used in the loop
            if filters[0] != '':
                # Parse out desired filter name for the first filter in the list
                formatted_name = self.namer.style_name(filters[0], self.namer.one_to_one_transforms[filters[0]])
                # Create initial IF statement along with its condition
                filter_condition_string = f'    IF {formatted_name} = TRUE\n        '
                self.object_map[name]['sub_components'].append(formatted_name)
                # Loop to add additional filters
                for filter_name in filters[1:]:
                    formatted_name = self.namer.style_name(filter_name, self.namer.one_to_one_transforms[filter_name])
                    filter_condition_string += f'AND {formatted_name} = TRUE\n        '
                    self.object_map[name]['sub_components'].append(formatted_name)
                # If more than one condition we want a THEN statement to precede our aggregation statement
                if len(filters) > 1:
                    filter_condition_string += 'THEN\n            '

            # The aggregate function to be executed in the loop
            aggregate = loop_specifics.attributes.get('aggregate').value
            # Assign variable to attribute upon which the aggregation function runs, use it to build aggregation string
            value = loop_specifics.attributes.get('value').value
            # Obtain desired format of name for the aggregate function parameter value
            if value.isupper():
                formatted_name = self.namer.style_name(value, self.namer.one_to_one_transforms[value])
                self.object_map[name]['sub_components'].append(formatted_name)
            elif value != '':
                value = f'{segment[:2]}.{value}'
                self.object_map[name]['sub_components'].append(value)
            else:
                value = 'SEGMENTS'

            # In case no aggregation function used in CA loop there is just an execution of the attribute on each segment
            if aggregate != '':
                aggregate_string = f"SET {self.object_map['name']} to {aggregate} of {value}\n"
            else:
                aggregate_string = f'EXECUTE {value}\n'

            # Build ending segment of pseudocde which includes ENDFOR/ENDIF and the RETURN statement 
            ending_string = f"    ENDIF\nENDFOR\n\nRETURN {self.object_map['name']}"

            # Build final string and add it along with its subcomponents to the excel sheet
            final_string = f'{init_string + loop_declaration_string + filter_condition_string + aggregate_string + ending_string}'
            self.object_map[name]['calculation'] = final_string
            
        def create_pseudocode(self):
            for i, loop in enumerate(self.objects):
                print(i)
                self.transcribe_loops(loop)


    class FilterGenerator():
        def __init__(self, parent):
            objects_to_generate = parent.query.get_filters()
            parent.__init__child__(self, objects_to_generate)
            self.word_mapper, self.parent = WordMapper(self.objects, self.all_object_names), parent

        def transcribe_filters(self, filter_map):
            split_result = filter_map['calculation'].split(' ')
            split_conditions, index_next_condition = list(), 0
            last_result_index = len(split_result) - 1

            for index, item in enumerate(split_result):
                if item in ('AND', 'OR') or (len(split_conditions) and index == last_result_index):
                    last_join_index = index if item in ('AND', 'OR', '') else index + 1
                    split_conditions.append([' '.join(split_result[index_next_condition:last_join_index]), item])
                    index_next_condition = index + 1
                elif index == last_result_index and not len(split_conditions):
                    split_conditions.append([' '.join(split_result), ''])
                    

            calculation = 'IF'
            for index, condition in enumerate(split_conditions):
                if condition[1] in ('AND', 'OR'):
                    calculation += f' {condition[0]}\n{" "*4}{condition[1]}'
                else:
                    calculation += f' {condition[0]}\n'
                    if len(split_conditions) > 1:
                        calculation += f'{" "*4}THEN\n{" "*4}'

                    calculation += f'{" "*4}RETURN TRUE\nELSE\n{" "*4}RETURN FALSE\nENDIF'
            
            filter_map['calculation'] = calculation
        
        def create_pseudocode(self):
            for i, obj in enumerate(self.objects):
                print(i)
                obj_map = self.parent.init_object_map(self, obj)
                self.transcribe_filters(obj_map)
            

    class AttributeGenerator():
        def __init__(self, parent):
            objects_to_generate = parent.query.get_globals() + parent.query.get_attributes()
            parent.__init__child__(self, objects_to_generate)
            self.word_mapper, self.parent = WordMapper(self.objects, self.all_object_names), parent
            

        def map_dimensional_scope(self, obj_map, full_name):
            result = obj_map['calculation']
            last_was_open_paren = False
            dim = 0
            char_dims = [-1 for i in range(len(result))]
            prev_paren = -1

            for i, c in enumerate(result):

                if c == '(' and not last_was_open_paren:
                    last_was_open_paren = True
                    char_dims[prev_paren+1:i+1] = [(dim-1) for j in range(prev_paren+1, i)] + [dim]
                    prev_paren = i
                elif c == ')' and not last_was_open_paren:
                    dim -= 1
                    char_dims[prev_paren+1:i+1] = [(dim) for j in range(prev_paren+1, i)] + [dim]
                    prev_paren = i
                elif c == '(' and last_was_open_paren:
                    dim += 1
                    char_dims[prev_paren+1:i+1] = [(dim-1) for j in range(prev_paren+1, i)] + [dim]
                    prev_paren = i
                elif c == ')' and last_was_open_paren:
                    last_was_open_paren = False
                    char_dims[prev_paren+1:i+1] = [(dim) for j in range(prev_paren+1, i)] + [dim]
                    prev_paren = i

                if c == '(':
                    difference = 0
                    for j in reversed(range(i)):
                        if not result[j].isalpha() and not (j == i-1 and result[j] == ' ') or j == 0:
                            difference = i-j
                            if difference >= 3 and result[j+1:i].replace(' ', '').lower() not in ('and', 'or', 'loop', 'between', 'in'):
                                dim_upd_range = range(j+1, i) if j != 0 else range(0, i)
                                for k in dim_upd_range:
                                    char_dims[k] = dim
                            elif difference >= 3 and result[j+1:i].replace(' ', '').lower() == 'loop':
                                self.word_mapper.loops.add(full_name)
                            break
            linked_dims = list()
            for i, c in enumerate(result):
                linked_dims.append({'char': c, 'dim': char_dims[i], 'abs_index': i})

            if len(char_dims) != len(result):
                import pdb;pdb.set_trace()

            obj_map['dims'] = {'char_dims': char_dims, 'linked_dims': linked_dims}
            

        def transform_keywords(self, obj_map, full_name):
            result = obj_map['calculation']
            char_dims = obj_map['dims']['char_dims']
            linked_dims = obj_map['dims']['linked_dims']
            max_dim = max(char_dims)
            current_iteration_dim = max_dim

            while current_iteration_dim >= 0:
                current_dim_fun_open_paren_indices = [i for i, link in enumerate(linked_dims) if link['char'] == '(' and link['dim'] == current_iteration_dim == linked_dims[i-1]['dim']]
                i = 0
                while i < len(current_dim_fun_open_paren_indices):
                    sub_fun = ''
                    sub_fun_end = 0
                    open_paren_i = current_dim_fun_open_paren_indices[i]
                    for j in reversed(range(open_paren_i)):
                        if j == 0 or char_dims[j-1] == current_iteration_dim-1:
                            keyword_start = j
                            if j == 0 and result[j] == '(':
                                keyword_start += 1
                            sub_fun = result[keyword_start:open_paren_i].replace(' ', '').lower()
                            if not sub_fun in ('if', 'iif'):
                                for k in range(open_paren_i, len(result)):
                                    if linked_dims[k]['char'] == ')' and linked_dims[k]['dim'] == current_iteration_dim:
                                        sub_fun_end = k
                                        fun = {
                                            'dim': current_iteration_dim, 
                                            'name':sub_fun, 
                                            'args': self.word_mapper.get_args(linked_dims[open_paren_i+1:sub_fun_end], current_iteration_dim, result, char_dims),
                                            'start_index': keyword_start,
                                            'end_index': sub_fun_end
                                        }
                                        arg_map = self.word_mapper.fun_map[fun['name']](self.word_mapper, fun['args'], full_name)
                                        transformation_map = self.word_mapper.get_transformation_map(arg_map, current_iteration_dim, fun)
                                        result_after_fun = result[fun['end_index']+1:]
                                        result = result[:fun['start_index']] + transformation_map['result']
                                        next_search_index = len(result)
                                        result += result_after_fun
                                        char_dims = char_dims[:fun['start_index']] + transformation_map['char_dims'] + char_dims[fun['end_index']+1:]
                                        if len(result) != len(char_dims):
                                            import pdb;pdb.set_trace()
                                        linked_dims = [{'char': c, 'dim': char_dims[i], 'abs_index': i} for i, c in enumerate(result)]
                                        current_dim_fun_open_paren_indices[i+1:] = [link['abs_index'] for i, link in enumerate(linked_dims[next_search_index:]) if link['char'] == '(' and link['dim'] == current_iteration_dim  == linked_dims[link['abs_index']-1]['dim']]
                                        break
                            break
                    i += 1                       
                current_iteration_dim -= 1

            if len(result) != len(char_dims):
                import pdb;pdb.set_trace()

            if max(char_dims) >= 4:
                self.longs.add(full_name)
            obj_map.update({'calculation': result, 'dims': {'char_dims': char_dims, 'linked_dims': linked_dims}})

        def transform_iifs(self, obj_map, full_name):
            result = obj_map['calculation']
            char_dims = obj_map['dims']['char_dims']

            if_dims = list()
            for i, c in enumerate(result):
                if result[i:i+3].lower() == 'iif':
                    if_dims.append(char_dims[i])
            if_dims= sorted(list(set(if_dims)), reverse=True)


            for current_iteration_dim in if_dims:
                current_dim_transform_done = False
                next_search_index = 0
                while not current_dim_transform_done:
                    for i in range(next_search_index, len(result)):
                        if result[i:i+3].lower() == 'iif' and char_dims[i] == current_iteration_dim:
                            open_paren_i = result[i:].index('(') + i
                            start_if_index = i
                            end_if_index = 0
                            first_comma_index = 0
                            sec_comma_index = 0
                            for j in range(open_paren_i, len(result)):
                                try:
                                   val = (result[j], char_dims[j]) == (')', current_iteration_dim)
                                except Exception:
                                    import pdb;pdb.set_trace() 
                                if (result[j], char_dims[j]) == (')', current_iteration_dim) and not end_if_index:
                                    end_if_index = j
                                    break
                                if (result[j], char_dims[j]) == (',', current_iteration_dim):
                                    if not first_comma_index:
                                        first_comma_index = j
                                    elif not sec_comma_index:
                                        sec_comma_index = j

                            transformation_text = f'\n{"    "*current_iteration_dim}IF'
                            if result[open_paren_i+1] != ' ':
                                transformation_text += ' '

                            conditions = result[open_paren_i+1:first_comma_index]
                            formatted_conditions = ''
                            multiple_conds = False
                            last_join_i = 0
                            for  k, c in enumerate(conditions):
                                if conditions[k:k+5].lower() == ' and ':
                                    formatted_conditions += conditions[last_join_i:k] + f'\n{"    "*(current_iteration_dim+1)}AND ' 
                                    last_join_i = k+4
                                    multiple_conds = True
                                elif conditions[k:k+4].lower() == ' or ':
                                    formatted_conditions += conditions[last_join_i:k] + f'\n{"    "*(current_iteration_dim+1)}OR '
                                    last_join_i = k+3
                                    multiple_conds = True
                                elif k == len(conditions) - 1:
                                    formatted_conditions += conditions[last_join_i:]
                                    if multiple_conds == True:
                                        formatted_conditions += f'\n{"    "*(current_iteration_dim+1)}THEN\n'
                                    else:
                                        formatted_conditions += f'\n'
                            if 'ELSE ' in formatted_conditions:
                                self.longs.add(full_name)

                            if not sec_comma_index:
                                true_ret_val = result[first_comma_index+1:end_if_index].strip()
                                else_ret_val = 'NULL'
                            else:
                                true_ret_val = result[first_comma_index+1:sec_comma_index].strip()
                                else_ret_val = result[sec_comma_index+1:end_if_index].strip()
                            if not true_ret_val:
                                import pdb;pdb.set_trace()
                            if true_ret_val[0] == '(' and true_ret_val[-1] == ')':
                                true_ret_val = true_ret_val[1:-1]

                            true_return_statement = f'{"    "*(current_iteration_dim+1)}'                            
                            else_return_statement = f'\n{"    "*(current_iteration_dim)}ELSE\n{"    "*(current_iteration_dim+1)}'

                            if true_ret_val[:2].lower() != 'if' and '* null' not in true_ret_val.lower():
                                if 'SET ' not in true_ret_val[:7]:
                                    true_return_statement += 'RETURN '
                            true_return_statement += true_ret_val

                            if else_ret_val[:2].lower() != 'if' and '* null' not in else_ret_val.lower():
                                if 'SET ' not in else_ret_val[:7]:
                                    else_return_statement += 'RETURN '
                            
                            if else_ret_val[0] == '(' and else_ret_val[-1] == ')':
                                else_ret_val = else_ret_val[1:-1]
                            else_return_statement += f'{else_ret_val}\n{"    "*(current_iteration_dim)}ENDIF\n'

                            if multiple_conds:
                                to_replace = ['    IF', '    RETURN', '    ELSE', '    ENDIF']
                                for s in to_replace:
                                    true_return_statement = true_return_statement.replace(s, f'    {s}')
                            transformation_text += f'{formatted_conditions}{true_return_statement}{else_return_statement}'

                            result = result[:start_if_index] + transformation_text + result[end_if_index+1:]
                            char_dims = char_dims[:start_if_index] + [current_iteration_dim for l in range(len(transformation_text))] + char_dims[end_if_index+1:]

                            next_search_index = end_if_index + 1

                            break
                        elif i == len(result) - 1:
                            current_dim_transform_done = True


            obj_map.update({'calculation': self.word_mapper.remove_island_multi_whites(result)})

        def summary_attribute_return(self, obj_map, obj_type):
            res = obj_map['calculation']
            if '+' in res[-5:] and '0' in res[-5:] and obj_type == 'GV':
                if '>' in res[-7:]:
                    ret_end_i = len(res) - res[::-1].index('>')
                    ret_val = res[:ret_end_i]
                    new_ret = f'IF {ret_val} = NULL\n    RETURN 0\nELSE\n    RETURN {ret_val}\nENDIF'
                    obj_map['calculation'] = new_ret
                else:
                    endif_i = len(res) - res[::-1].index('FIDNE') 
                    obj_map['calculation'] = res[:endif_i]
                self.news.append(obj_map['calculation'])
            elif '<' == res.strip()[0] and '>' == res.strip()[-1]:
                obj_map['calculation'] = f'RETURN {res.strip()}' 

        def create_pseudocode(self):
            self.longs = set()
            self.news = list()
            
            for i, obj in enumerate(self.objects):
                print(i)
                if 'ADDGP02SEG' not in obj.attributes.get('result').value:
                    full_name = obj.attributes.get('name').value
                    obj_map = self.parent.init_object_map(self, obj)
                    self.map_dimensional_scope(obj_map, full_name)
                    self.transform_keywords(obj_map, full_name)
                    self.transform_iifs(obj_map, full_name)
                    self.summary_attribute_return(obj_map, full_name[:2])
                    self.add_possible_suspect(obj_map['calculation'], full_name)
            
            word_suspects = [self.word_mapper.manuals, self.word_mapper.loops, self.word_mapper.executors]
            self.suspects = self.longs.union(*word_suspects)
            self.write_suspects_excel()

            return {'all': self.object_map.values(), 'suspects': self.suspects}
        
        def add_possible_suspect(self, calculation, name):
            if 'ENDIF +' in calculation or 'ENDIF+' in calculation or 'ENDIF  +' in calculation:
                self.longs.add(name)
            
            for line in calculation.split('\n'):
                if (len(line.strip()) >= 50 and 'ROUNDED to INTEGER' not in line.strip()[-20:]) or '~' in line:
                    self.longs.add(name)
                

        def write_suspects_excel(self):
            wb = Workbook() 
            for suspect in self.suspects:
                calculation = self.object_map[suspect]['calculation']
                wb.active.append([suspect, calculation])
            for row in wb.active.iter_rows():
                for cell in row:
                    cell.alignment = Alignment(wrap_text=True)
            wb.save('tC_man.xlsx')
