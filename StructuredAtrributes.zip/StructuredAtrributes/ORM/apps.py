from django.apps import AppConfig


class OrmConfig(AppConfig):
    name = 'ORM'
    verbose_name = 'Equifax 5.0 Attributes'
