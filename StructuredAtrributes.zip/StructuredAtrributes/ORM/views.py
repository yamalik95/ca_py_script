from django.shortcuts import render, redirect, render_to_response
from ORM.models import PseudocodeObject
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def explode_up(request, obj_id):
    obj = PseudocodeObject.objects.get(id=obj_id)
    masters = obj.master_components.all()
    return render(request, 'explode.html', {'masters': masters, 'base_subject': obj})