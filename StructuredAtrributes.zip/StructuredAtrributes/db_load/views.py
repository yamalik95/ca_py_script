from django.shortcuts import render, redirect


def get_file_input_form(request):
    if request.method == 'GET':
        return render(request, 'file_input.html')