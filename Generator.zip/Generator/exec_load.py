from generators import PseudocodeGenerator
# from ORM.models import PseudocodeObject
from bureau_map import BUREAUS
from consolidate import Consolidator

class Loader():
    def __init__(self):
        self.generators = dict()
        for bureau, prefix in BUREAUS.items():
            print(f'Initializing {bureau} Pseudocode Generator')
            G = self.generators[bureau] = PseudocodeGenerator(f'{prefix}.XML', bureau)
            self.create_pseudocode(G, bureau)
            G.object_map = {
                **G.attribute_generator.object_map, 
                **G.loop_generator.object_map,
                **G.filter_generator.object_map,
                **G.interrogation_generator.object_map
            }
            Consolidator(bureau, prefix, G)

    def create_pseudocode(self, generator, bureau):
        print(f'Creating {bureau} Pseudocode')
        luts = generator.interrogation_generator.create_pseudocode()
        loops = generator.loop_generator.create_pseudocode()
        filters = generator.filter_generator.create_pseudocode()
        attributes = generator.attribute_generator.create_pseudocode()
        # for i, obj in enumerate(creations['all']):
        #     print(f'Loading {i}...')
        #     fields = {k:v for k,v in obj.items() if k != 'dims'}
        #     if obj['name'] in creations['suspects']:
        #         fields['data_note'] += 'suspect'
        #     fields['bureau'] = self.generator.bureau
            

loader = Loader()
