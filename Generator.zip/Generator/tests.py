from generators import PseudocodeGenerator
print('hello')
generator = PseudocodeGenerator('eq6.XML').attribute_generator
generator.create_pseudocode()
import pdb;pdb.set_trace()