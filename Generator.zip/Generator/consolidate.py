import xlrd
from openpyxl import Workbook # For writing to an excel sheet
from openpyxl.styles import Alignment # For styling an excel sheet

class Consolidator():
    def __init__(self, bureau, file_prefix, generator):
        self.data = {'bureau': bureau, 'file_prefix': file_prefix, 'G': generator}
        self.update_generator_objects()
        self.write_excel()


    def update_generator_objects(self):
        attr_mans = xlrd.open_workbook(f"{self.data['file_prefix']}_man.xlsx").sheet_by_index(0)
        filter_mans = xlrd.open_workbook(f"{self.data['file_prefix']}_filters_man.xlsx").sheet_by_index(0)
        all_mans = [(attr_mans.cell_value(i, 0), attr_mans.cell_value(i, 1)) for i in range(attr_mans.nrows)]
        all_mans += [(filter_mans.cell_value(i, 0), filter_mans.cell_value(i, 1)) for i in range(filter_mans.nrows)]
        for man in all_mans:
            self.data['G'].object_map[man[0]]['calculation'] = man[1]
        
    def write_excel(self):
        self.wb_simples, self.wb_tables = Workbook(), Workbook()
        objects = self.data['G'].object_map
        write_options = {1: self.write_simple, 0: self.write_table}
        for full_name, obj_map in objects.items():
            decision = 'S' != full_name[1]
            write_options[decision](full_name, obj_map)
        self.save_styled_xlsx(self.wb_simples, self.wb_tables)

    def write_simple(self, full_name, obj_map):
        if '$' in obj_map['calculation'] or '*null' in obj_map['calculation'].replace(' ', '').lower():
            obj_map['calculation'] += '\n*REVISE'
        self.wb_simples.active.append(
            [
                full_name,
                obj_map['name'],
                obj_map['object_type'],
                obj_map['description'],
                obj_map['calculation'],
                '\n'.join(obj_map['sub_components'])
            ]
        )
    
    def write_table(self, full_name, obj_map):
        calc = '\n'.join([f"{' '.join(row[:3])}  :  {row[3]}" for row in obj_map['interrogations']])
        self.wb_tables.active.append(
            [
                full_name,
                obj_map['name'],
                obj_map['object_type'],
                obj_map['description'],
                calc,
                '\n'.join(obj_map['sub_components'])
            ]
        )

    def save_styled_xlsx(self, *workbooks):
        for i, wb in enumerate(workbooks):
            for row in wb.active.iter_rows():
                for cell in row:
                    cell.alignment = Alignment(wrap_text=True)
            wb.save(f"{self.data['file_prefix']}_{i}.xlsx")
