import xlrd
old = xlrd.open_workbook('t41_man.xlsx')
new = xlrd.open_workbook('eq7_man.xlsx')
old_sheet = old.sheet_by_index(0)
new_sheet = new.sheet_by_index(0)

old_names = set()
new_names = set()

for i in range(old_sheet.nrows):
    old_names.add(old_sheet.cell_value(i, 0))

for i in range(new_sheet.nrows):
    new_names.add(new_sheet.cell_value(i, 0))

for name in new_names:
    if name not in old_names:
        print(name)
                   
                    