BUREAUS = {
    'Equifax 6.0': 'eq6', 
    'Equifax 7.0': 'eq7', 
    'TransUnion 4.0': 't40', 
    'TransUnion 4.1': 't41', 
    'EquifaxC': 'eqC', 
    'TransUnionC': 'tC', 
    'Experian 7.0': 'xp7'
}