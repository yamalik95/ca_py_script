from generators import PseudocodeGenerator
# from ORM.models import PseudocodeObject

class Loader():
    def __init__(self):
        self.generator = PseudocodeGenerator('eq7.XML', 'Equifax 7.0')

    def load_attributes(self):
        creations = self.generator.attribute_generator.create_pseudocode()
        # for i, obj in enumerate(creations['all']):
        #     print(f'Loading {i}...')
        #     fields = {k:v for k,v in obj.items() if k != 'dims'}
        #     if obj['name'] in creations['suspects']:
        #         fields['data_note'] += 'suspect'
        #     fields['bureau'] = self.generator.bureau
            

loader = Loader()
loader.load_attributes()