import xlrd
from openpyxl import Workbook
from openpyxl.styles import Alignment

wbr = xlrd.open_workbook('eq7_man.xlsx')
wsr = wbr.sheet_by_index(0)

wbw = Workbook()

for i in range(wsr.nrows):
    name = wsr.cell_value(i, 0)
    calc = wsr.cell_value(i, 1)
    if 'GROUPED_INQ_VAL_' in name and len(name) == 40:
        calc = ''
        abbr = name[-9:-6].lower()
        num = name[-2:]
        holdcat = f'holdcat_{abbr}_nc0{num}'
        holddate = f'holddate_{abbr}_nc0{num}'
        calc += f"IF [CAT_PRD2] IN ('AUT', 'MRE')\n    "
        calc += f"IF {holdcat} DOESN'T EXIST INITIIALIZE {holdcat} to NULL\n    "
        calc += f"IF {holddate} DOESN'T EXIST INITIIALIZE {holddate} to NULL\n    "
        calc += f"IF {holdcat} <> NULL\n        "
        calc += f"SET {holdcat} to [CAT_PRD2]\n        "
        calc += f"SET {holddate} to IQ.daterep\n        "
        calc += f"RETURN 1\n    ELSE\n        "
        calc += f"IF ABS({holddate} - IQ.daterep) >= 30\n            "
        calc += f"SET {holddate} to IQ.daterep\n            RETURN 1\n        "
        calc += f"ELSE\n            RETURN 0\n        ENDIF\n    ENDIF\nELSE\n    "
        calc += f"RETURN 1\nENDIF"
    elif 'US008' == name[-5:]:
        abbr1 = name[-11]
        abbr2 = name[-9:-6]
        f_name = f'<FL_{abbr1}_{abbr2}_US007>'
        calc = f"IF {f_name} in (0, NULL)\n    {calc[calc.index('RETURN NULL'):]}"
    
    calc = calc.replace('~0', '').replace(' ~ 0', '').replace('~ 0', '')


    wbw.active.append([name, calc])

for row in wbw.active.iter_rows():
    for cell in row:
        cell.alignment = Alignment(wrap_text=True)

wbw.save('eq7_man2.xlsx')