from ORM.models import PseudocodeObject as P
from ORM.models import LUTInterrogation as I
import xlrd

bureau_abbrs = {'eq6': 'Equifax 6.0', 'eq7': 'Equifax 7.0', 'eqC': 'Equifax CA', 't40': 'TransUnion 4.0', 't41': 'TransUnion 4.1', 'tC': 'TransUnion CA', 'xp7': 'Experian 7.0'}

# for abbr, bureau in bureau_abbrs.items():
#     non_luts = xlrd.open_workbook(f"./pseudocode/{abbr}_0.xlsx").sheet_by_index(0)
#     luts = xlrd.open_workbook(f"./pseudocode/{abbr}_1.xlsx").sheet_by_index(0)

#     # for i in range(non_luts.nrows):
#     #     val = non_luts.cell_value
#     #     obj = {'name': val(i, 1), 'description': val(i, 3), 'object_type': 'attribute component', 'calculation': val(i, 4), 'bureau': bureau, 'sub_components': val(i, 5)}

#     #     if 'GV' in val(i, 0) and len(val(i, 0)) == 21:
#     #             obj['object_type'] = 'summary attribute'

#     #     P(**obj).save()
    
#     for i in range(luts.nrows):
#         val = luts.cell_value
#         obj = {'name': val(i, 1)[1:-1], 'description': val(i, 3), 'object_type': 'look-up table', 'bureau': bureau, 'sub_components': val(i, 5), 'data_default': val(i, 6)}
#         lut = P(**obj)
#         lut.save()
#         ints = val(i, 4).split('\n')
#         for j, line in enumerate(ints[::-1]):
#             split_line = line.split(' ')
#             if len(split_line) > 1:
#                 int_obj = {'bureau': bureau, 'field_to_interrogate': split_line[0], 'interrogation_operator': split_line[1], 'interrogation_target': split_line[2], 'interrogation_return': split_line[-1], 'index': len(ints) - 1 - j, 'master': lut}
#                 interrogation = I(**int_obj)
#                 interrogation.save()


F = P.objects.filter
querysets = {'Equifax 6.0': F(bureau='Equifax 6.0'), 'Equifax 7.0': F(bureau='Equifax 7.0'), 'Equifax CA': F(bureau='Equifax CA'), 'TransUnion 4.0': F(bureau='TransUnion 4.0'), 'TransUnion 4.1': F(bureau='TransUnion 4.1'), 'TransUnion CA': F(bureau='TransUnion CA'), 'Experian 7.0': F(bureau='Experian 7.0')}
all_objs = list(P.objects.exclude(bureau='Equifax 5.0'))
for i, obj in enumerate(all_objs):
        print(f'{i+1} / {len(all_objs)}')
        subs = obj.sub_components.split('\n')
        for sub in subs:
            if len(sub) and '.' in sub:
                tag = F(name=sub, bureau=obj.bureau, object_type='bureau tag')
                if not len(tag):
                    tag = P(name=sub, bureau=obj.bureau, object_type='bureau tag')
                    tag.save()
                else:
                    tag = tag[0]
                obj.subject_components.add(tag)
                tag.master_components.add(obj)
