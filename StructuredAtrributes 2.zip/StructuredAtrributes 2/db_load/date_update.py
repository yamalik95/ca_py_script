import sys, os, django
sys.path.append("..")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "StructuredAtrributes.settings")
django.setup()
from ORM.models import PseudocodeObject as P
from db_load.names import NameSpaceMapper as N

non_eq5_bureaus = {
    'eq6': 'Equifax 6.0', 
    'eq7': 'Equifax 7.0', 
    'eqC': 'EquifaxC', 
    't40': 'TransUnion 4.0', 
    't41': 'TransUnion 4.1', 
    'tuC': 'TransUnionC', 
    'xp7': 'Experian 7.0'
}

namers, objs_by_bureau = dict(), dict()
for bureau_abbr, bureau_full in non_eq5_bureaus.items():
    namers[bureau_abbr] = namer = N(f'db_load/xml/{bureau_abbr}.XML', bureau_full)
    objs_by_bureau[bureau_abbr] = objs = P.objects.filter(bureau=bureau_full.replace('C', ' CA'))
    namespace = {short_name: full_name for full_name, short_name in namer.one_to_one_transforms.items()}
    xml_objs = namer.query.get_all_objects()
    for db_obj in objs:
        full_name = namespace[db_obj.name]
        for xml_obj in xml_objs:
            if full_name == xml_obj.attributes.get('name').value:
                db_obj.last_updated = xml_obj.attributes.get('datelastupdated').value
                db_obj.ca_name = full_name
                db_obj.save()
