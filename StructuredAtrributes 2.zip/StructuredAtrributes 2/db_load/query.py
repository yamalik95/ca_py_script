class QueryHandler():
    def __init__(self, xml_tree):
        self.xml = xml_tree
        self.functions = self.xml.getElementsByTagName('FUNCTION')

    def get_object_identifier(self, obj):
        return obj.attributes.get('name').value[1]

    def get_globals(self):
        return list(self.xml.getElementsByTagName('USERVAR'))

    def get_loops(self):
        return [fun for fun in self.functions if self.get_object_identifier(fun) == 'L']

    def get_filters(self):
        return [fun for fun in self.functions if self.get_object_identifier(fun) == 'F']

    def get_attributes(self):
        return [fun for fun in self.functions if self.get_object_identifier(fun) == 'A']

    def get_lookups(self):
        return [fun for fun in self.functions if self.get_object_identifier(fun) == 'S']

    def get_all_objects(self):
        return self.get_globals() + self.get_loops() + self.get_filters() + self.get_attributes() + self.get_lookups()
    
    def get_multiple_object_sets(self, *obj_types):
        subset = list()
        for obj_type in obj_types:
            subset += object_type_map[obj_type]()

    def get_all_segments(self):
        s

    object_type_map = {
        'gv': get_globals,
        'fl': get_loops,
        'ff': get_filters,
        'fa': get_attributes,
        'fs': get_lookups,
        'all': get_all_objects
    }