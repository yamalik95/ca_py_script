from xml.dom import minidom # For reading XML files into a python data structure
from .query import QueryHandler

class NameSpaceMapper():
    def __init__(self, xml_file, bureau):
        format_abbrs = {'Equifax': 'EQ', 'TransUnion': 'T', 'Experian': 'XP', 'EquifaxC': 'EQC', 'TransUnionC': 'TUC'}
        version_map = {'5.0': '5', '6.0': '6', '7.0': '7', '4.0': '40', '4.1': '41'}
        self.format_abbr = format_abbrs[bureau.split(' ')[0]]
        self.version_num = version_map.get(bureau.split(' ')[-1], '')
        self.xml =  minidom.parse(xml_file)
        self.query = QueryHandler(self.xml)

        for object_type in ('gv', 'fl', 'ff', 'fa', 'fs', 'all'):
            self.get_single_dimension_namespace(object_type)

        self.one_to_one_transform()

    class NameSpace():
        def __init__(self, raw_objects):
            self.objects = raw_objects
            self.maps = {'all': dict(), 'one_to_many_self': dict(), 'one_to_many_cross': dict(), 'one_to_one_cross': dict()}

        def filter_one_to_many_single_dimension(self):
            self.maps['one_to_many_self'] = {
                split_name:full_name_matches for (split_name, full_name_matches) in self.maps['all'].items() if len(full_name_matches) > 1
            }

        def segregate_cross_dimension_mappings(self):
            for (split_name, full_name_matches) in self.maps['all'].items():
                if len(full_name_matches) > 1:
                    first_dim = full_name_matches[0][:2]
                    for name in full_name_matches:
                        if name[:2] != first_dim:
                            self.maps['one_to_many_cross'][split_name] = full_name_matches
                elif len(full_name_matches) == 1:
                    self.maps['one_to_one_cross'][full_name_matches[0]] = split_name

    def get_all_single_dimension_maps(self):
        return [self.gv_namespace] + [self.fl_namespace] + [self.ff_namespace] + [self.fa_namespace] + [self.fs_namespace]

    def get_split_name(self, name): # For truncating CA object names into a specified format which includes only the most operational part of the name
        if f'GV_{self.format_abbr}{self.version_num}_V6' in name:
            return name[10:]
        elif f'{self.format_abbr}{self.version_num}_V6' in name or 'EFX_V6' in name:
            return name[13:]
        elif name == 'FF_ID_EFX_BUREAU':
            return name[3:]
        elif 'EFX' in name:
            return name[10:]
        elif name == 'GV_SW_DELIMITER':
            return name[3:]
        else:
            return name[6:]

    def style_name(self, full_name, split_name):
        if 'S' == full_name[1]:
            return f'[{split_name}]'
        else:
            return f'<{split_name}>'

    def get_single_dimension_namespace(self, object_type):
        objects = self.query.object_type_map[object_type.lower()](self.query)
        namespace = self.NameSpace(objects) # Initialize NameSpaceMap to map any name intersectionality across objects with respect to the initial formatted name 
        
        for obj in namespace.objects: # Loop across each XML element in the object segregation set
            full_name = obj.attributes.get('name').value # Store full name of the object returned by the current step in the iteration sequence
            split_name = self.get_split_name(full_name) # Store formatted name of the object returned by the current step in the iteration sequence

            # Attempt retrieval of the previously stored global variables names which map onto the most recently generated formatted name   
            namespace.maps['all'].update({split_name: namespace.maps['all'].get(split_name, []) + [full_name]}) # If the formatted name has no previously stored matches, create a new list to store the match for the current full object name
            # Assign/update the emergent name map with respect to this iterative step
        if object_type != 'all':
            namespace.filter_one_to_many_single_dimension() # Extract any name mappings which are not one-to-one 
        else:
            namespace.segregate_cross_dimension_mappings()

        self.__dict__[f'{object_type}_namespace'] = namespace # Return newly created object name self-intersectionality map

    def one_to_one_transform(self):
        one_to_one_map = dict()
        all_single_dimension_maps = self.get_all_single_dimension_maps()

        for map_obj in all_single_dimension_maps:
            for (formatted_name, full_names) in map_obj.maps['one_to_many_self'].items():
                for full_name in full_names:
                    one_to_one_map[full_name] = f'{full_name[3:6]}{formatted_name}'

        for (formatted_name, full_names) in self.all_namespace.maps['one_to_many_cross'].items():
            for full_name in full_names:
                one_to_one_map.update({full_name: f'{full_name[:3]}{one_to_one_map.get(full_name, formatted_name)}'}) 
        


        for full_name in self.all_namespace.maps['one_to_one_cross'].keys():
            if full_name in one_to_one_map.keys():
                error = 'full name found in both one_to_many_cross and one_to_one_cross'
                print(error)
                import pdb;pdb.set_trace()
        
        one_to_one_map.update(self.all_namespace.maps['one_to_one_cross'])
        self.one_to_one_transforms = one_to_one_map
        

