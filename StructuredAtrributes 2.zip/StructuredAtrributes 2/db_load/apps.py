from django.apps import AppConfig


class DbLoadConfig(AppConfig):
    name = 'db_load'
