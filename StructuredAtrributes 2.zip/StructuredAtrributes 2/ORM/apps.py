from django.apps import AppConfig


class OrmConfig(AppConfig):
    name = 'ORM'
    verbose_name = 'V6 Attribute Repository'
