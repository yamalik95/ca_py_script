from django.shortcuts import render
from ORM.models import PseudocodeObject
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse


def explode_up(request, obj_id):
    base_subject_obj = PseudocodeObject.objects.get(id=obj_id)
    base_subject_context = {
        'name': base_subject_obj.name,
        'id': obj_id
    }
    base_masters_contexts = [
        {'name': master.name, 'id': master.id} for master in base_subject_obj.master_components.all()
    ]
    context = {
        'base_subject': base_subject_context,
        'base_masters': base_masters_contexts
    }

    if 'inline' not in request.path:
        return render(request, 'explode.html', context)
    else:
        return JsonResponse(context)

    