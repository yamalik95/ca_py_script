from xml.dom import minidom
from openpyxl import Workbook
from openpyxl.styles import Alignment

wb, worksheets = Workbook(), list()

prd_tables = ['FS_TR_XP7_V6_CAT_PRD_LT_I', 'FS_TR_XP7_V6_CAT_PRD_LT_R', 'FS_IQ_XP7_V6_CAT_PRD_LT']
prd_cats = ['AUT', 'CCB', 'CCO', 'CCR', 'EDU', 'LOC', 'MAR', 'MHL', 'MLC', 'MRT', 'OIN', 'ORE', 'ORV']
acct_types = ['Installment', 'Revolving', 'Irrelevant']
segments = ['Tradeline', 'Tradeline', 'Inquiry']
parsed_xml = minidom.parse('xp7.XML')


for cat_i, cat in enumerate(prd_cats):
    worksheets.append(wb.create_sheet(cat))
    worksheets[cat_i].append(['SEGMENT', '*AND*', 'ACCOUNT TYPE', '*AND*', 'LOANTYPE\n**OR**', '*AND*', 'KOB\n**OR**'])
    for table_i in range(3):
        target_table, target_cat, cond_dict = prd_tables[table_i], cat, dict()
        tables = parsed_xml.getElementsByTagName('SELECTCASE')
        direct_returns = {}
        indirect_returns = {}

        def insert_cond(cond, cond_dict):
            split_cond = cond.split(' ')
            param_op, target = ' '.join(split_cond[:2]), split_cond[2]
            cond_dict[param_op] = cond_dict.get(param_op, []) + [target]

        for table in tables:
            cases = table.getElementsByTagName('CASE')
            if table.parentNode.attributes.get('name').value == target_table:
                for case in cases:
                    get = case.attributes.get
                    if get('result').value.strip()[1:-1] == target_cat:
                        insert_cond(get('test').value, direct_returns)
                    elif get('returntype').value == 'Attribute':
                        ret_val = get('result').value
                        indirect_returns[ret_val] = indirect_returns.get(ret_val, []) + [get('test').value]

        paired_conds = dict()
        for return_table, conditions in indirect_returns.items():
            paired_conds[return_table] = conditions + ['&&']
            is_table = False
            for table in tables:
                cases = table.getElementsByTagName('CASE')
                if table.parentNode.attributes.get('name').value == return_table:
                    is_table = True
                    found_target_cat = False
                    for case in cases:
                        if case.attributes.get('result').value.strip()[1:-1] == target_cat:
                            found_target_cat = True
                            paired_conds[return_table].append(case.attributes.get('test').value)
                        elif case.attributes.get('returntype').value == 'Attribute':
                            import pdb;pdb.set_trace()
                    if not found_target_cat:
                        del paired_conds[return_table]
                    break
            if not is_table:
                paired_conds[return_table][0] += '*********'

        print(prd_tables[table_i])
        for param_op, targets in direct_returns.items():
            cleaned_targets = list()
            for tar_i, tar in enumerate(targets):
                tar = f'{tar}    '
                if (tar_i+1) % 15 == 0:
                    tar += '\n'
                cleaned_targets.append(tar.replace("'", '').replace('"', ''))
            targets_str = ''.join(cleaned_targets)
            new_ws_row = [segments[table_i], '', acct_types[table_i], '', targets_str, '', 'Irrelevant']
            worksheets[cat_i].append(new_ws_row)
            print(f"{param_op}  :  {targets_str}")
        print('\n')
            

        transformed_indirects = dict()
        for table, conditions in paired_conds.items():
            transformed_indirects[table] = [dict(), dict()]
            slice_index = conditions.index('&&')
            tiered_conds = [conditions[:slice_index], conditions[slice_index+1:]]
            for i, conds in enumerate(tiered_conds):
                [insert_cond(cond, transformed_indirects[table][i]) for cond in conds]

        for table in transformed_indirects:   
            conds = list(transformed_indirects[table][0].items()) + list(transformed_indirects[table][1].items())
            if len(conds) != 2:
                import pdb;pdb.set_trace()
            else:
                cleaned_targets = [list(), list()]    
                for col_i, (param_op, targets) in enumerate(conds):
                    for tar_i, tar in enumerate(targets):
                        tar = f'{tar}    '
                        if (tar_i+1) % 15 == 0:
                            tar += '\n'
                        cleaned_targets[col_i].append(tar.replace("'", '').replace('"', ''))
                    cleaned_targets[col_i] = ''.join(cleaned_targets[col_i])     
                    targets_str = '    '.join(targets).replace("'", '').replace('"', '')
                    print(f"{param_op}  :  {targets_str}")
                new_ws_row = [segments[table_i], '', acct_types[table_i], '', cleaned_targets[0], '', cleaned_targets[1]]
                worksheets[cat_i].append(new_ws_row)
            print('\n')
        print('\n\n')

for ws in worksheets:
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True)

wb.save('xp7_categorizations.xlsx')


