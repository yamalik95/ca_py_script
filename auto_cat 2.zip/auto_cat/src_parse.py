from xml.dom import minidom
from openpyxl import Workbook
from openpyxl.styles import Alignment

wb, worksheets = Workbook(), list()

def get_table(name, tables=minidom.parse('eq6.XML').getElementsByTagName('SELECTCASE')):
    for table in tables:
        if table.parentNode.attributes.get('name').value == name:
            return table

src_tables = [
    (get_table('FS_TR_EQ6_V6_CAT_SRC_CCC_I'), get_table('FS_TR_EQ6_V6_CAT_SRC_KOB_I')),
    (get_table('FS_TR_EQ6_V6_CAT_SRC_CCC_R'), get_table('FS_TR_EQ6_V6_CAT_SRC_KOB_R')),
    get_table('FS_IQ_EQ6_V6_CAT_SRC')
]
src_cats = ['BNK', 'CRU', 'NBF', 'PFN', 'RTL', 'TCL', 'TCM', 'UTL']
acct_types = ['Installment', 'Revolving', 'Irrelevant']
segments = ['Tradeline', 'Tradeline', 'Inquiry']



for cat_i, cat in enumerate(src_cats):
    worksheets.append(wb.create_sheet(cat))
    column_headers = ['SEGMENT', '*AND*', 'ACCOUNT TYPE', '*AND*', 'CREDCLASS', '*OR*', 'KOB\n**OR**']
    worksheets[cat_i].append(column_headers)

    for seg_i, seg in enumerate(segments):
        if seg != 'Inquiry':
            try:
                first_table, second_table = src_tables[seg_i][0], src_tables[seg_i][1]
                first_cases, second_cases = first_table.getElementsByTagName('CASE'), second_table.getElementsByTagName('CASE')
            except Exception:
                import pdb;pdb.set_trace()
            first_relevant, second_relevant, first_targets, second_targets = False, False, list(), list()
            new_row = [seg, '', acct_types[seg_i], '', 'Unrecognized', '', 'Irrelevant']
            for case in first_cases:
                if case.attributes.get('result').value.strip()[1:-1] == cat:
                    first_relevant = True
                    first_targets.append(case.attributes.get('value').value.replace('"', '').replace("'", ''))
            for case in second_cases:
                if case.attributes.get('result').value.strip()[1:-1] == cat:
                    second_relevant = True
                    second_targets.append(case.attributes.get('value').value.replace('"', '').replace("'", ''))
            if first_relevant:
                for tar_i, tar in enumerate(first_targets):
                    first_targets[tar_i] = f'{tar}    '
                    if (tar_i+1) % 10 == 0:
                        first_targets[tar_i] += '\n'
                new_row[4] = ''.join(first_targets)
            if second_relevant:
                for tar_i, tar in enumerate(second_targets):
                    second_targets[tar_i] = f'{tar}    '
                    if (tar_i+1) % 10 == 0:
                        second_targets[tar_i] += '\n'
                new_row[-1] = ''.join(second_targets)
            worksheets[cat_i].append(new_row)
        else:
            inq_table = src_tables[-1]
            inq_cases = inq_table.getElementsByTagName('CASE')
            kob_targets = list()
            for case in inq_cases:
                if case.attributes.get('result').value.strip()[1:-1] == cat:
                    kob_targets.append(case.attributes.get('value').value.replace('"', '').replace("'", ''))
            for tar_i, tar in enumerate(kob_targets):
                kob_targets[tar_i] += '    '
                if (tar_i+1) % 10 == 0:
                    kob_targets[tar_i] += '\n'
            if len(kob_targets):
                worksheets[cat_i].append([seg, '', acct_types[seg_i], '', 'Irrelevant', '', ''.join(kob_targets)])

for ws in worksheets:
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True)

wb.save('eq6_src.xlsx')